source(resolve.R)
n = 10
B = runif(n^2)
B = matrix(B, nrow = n)
A = t(B)*B
b = rep(1,n)
x1_chol = resolve(A,b)